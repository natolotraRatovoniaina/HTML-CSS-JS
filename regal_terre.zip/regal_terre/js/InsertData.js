showChargement()
let newArrivage = null
let BestPrice = null
let BestIntru = null
let view = null
let MonPanier = []
/**
 * @param {string} json
 * @returns {json}
 */
async function getData(json){
    let data = await fetch(json)
    let dataSplit = data.json()
    return dataSplit;
}

///maka ny new-arrivage

getData("../json/NewArrivage.json")
.then((data)=>{
    newArrivage = data
    Change(newArrivage,".new-arrivage .produit")
})
.catch((error)=>(console.error(error)))

///maka ny best-price

getData("../json/BestPrice.json")
.then((data)=>{
    BestPrice = data
    ChangeData(0)
})
.catch((error)=>(console.error(error)))

/// maka ny best-intru

getData("../json/BestIntru.json")
.then((data)=>{
    BestIntru = data
    Change(BestIntru,".best-intru .produit")
})
.catch((error)=>(console.error(error)))

/// maka ny Onsale

getData("../json/Onsale.json")
.then((data)=>{
    BestIntru = data
    Change(BestIntru,".sale2 .produit")
})
.catch((error)=>(console.error(error)))

/**
 * 
 * @param {json} donnee 
 * @param {string} container 
 */

function Change(donnee,container){
    let Container = document.querySelector(container)
    let template = document.getElementById("template-produit")
    donnee.forEach(element => {
        let items = template.content.cloneNode(true)
        let img = items.querySelector("img")
        img.src = "../Img/"+element.src
        let desc = items.querySelector(".description")
        desc.innerText = element.desc
        let price = items.querySelector(".price")
        price.innerText = "$"+element.price.toFixed(2)
        let button = items.querySelector("button")
        button.addEventListener('click',()=>addCart(element))
        Container.appendChild(items)
    })
}

/// ajouter au panier

function addCart(donnee){
    let exit = false
    let nb = 0
    if(MonPanier.length!=0){
        MonPanier.forEach(element=>{
            if(element.id == donnee.id){
                element.nb+=1
                exit = true
            }
        })
        if(!exit){
            donnee.nb = 1
            MonPanier.push(donnee)
        }
    }
    else{
        donnee.nb = 1
        MonPanier.push(donnee)
    }
    NbItteration()
}

/// afficher le panier

function showCart(){
    if(MonPanier.length!=0){
    let panier = document.getElementById("monpanier")
    let panierClone = panier.content.cloneNode(true)
    let items = panierClone.querySelector(".panier-produit .prod-princ .prod-items")
    let princ = panierClone.querySelector(".prod-princ")
    let labelTotal = panierClone.querySelector(".total")
    let total = 0
    princ.innerHTML=""
    MonPanier.forEach(element=>{
        let itemsClone = items.cloneNode(true)
        let img = itemsClone.querySelector("img")
        img.src = "../Img/"+element.src
        let desc = itemsClone.querySelector(".desc")
        desc.innerText = element.desc
        let nb = itemsClone.querySelector("input")
        nb.addEventListener("change",()=>ChangeNb(element.id,nb))
        nb.value = element.nb
        let price = itemsClone.querySelector(".panier-price")
        price.innerText = "$"+(element.price * element.nb).toFixed(2)
        let remove = itemsClone.querySelector(".delete")
        remove.addEventListener('click',()=>removeProduit(element.id))
        total+=(element.price * element.nb)
        princ.appendChild(itemsClone)
    })
    labelTotal.innerText = "TOTAL : $"+total.toFixed(2)
    document.body.appendChild(panierClone)
    }
    else{
        let panier = document.getElementById("panier-vide")
        let panierClone = panier.content.cloneNode(true)
        document.body.appendChild(panierClone)
    }
    document.body.style="overflow:hidden"
}


/// supprimer le panier

function hiddenCart(){
    document.body.removeChild(document.body.querySelector(".panier-float"))
    document.body.style="overflow:scroll"
}

/// change le nombre de produit dans le panier

function ChangeNb(index,element){
    MonPanier.forEach(elt=>{
        if(elt.id == index){
            elt.nb = parseInt(element.value)
        }
    })
    hiddenCart()
    showCart()
    NbItteration()
}

/// change le nombre visisble sur le panier

function NbItteration(){
    let CartNb = document.querySelector(".cart-nb")
    let nb = 0
    if(MonPanier.length!=0){
    MonPanier.forEach(elt=>{
        nb+=parseInt(elt.nb)
    })
    CartNb.style="display:flex"
    CartNb.innerHTML = nb
    }
    else{
        CartNb.style="display:none"
    }
}

/// supprime un produit dans le panier

function removeProduit(index){
    const MonPanierTmp = MonPanier.filter(element=>element.id!==index)
    MonPanier = MonPanierTmp
    hiddenCart()
    showCart()   
    NbItteration()
}
